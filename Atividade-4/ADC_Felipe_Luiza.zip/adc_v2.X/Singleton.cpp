/*
 * Singleton.cpp
 *
 *  Created on: 28 de set de 2016
 *      Author: arliones.hoeller
 */

#include "Singleton.h"

